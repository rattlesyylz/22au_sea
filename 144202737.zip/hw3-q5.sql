SELECT DISTINCT F1.dest_city AS city
FROM [dbo].[FLIGHTS] AS F1 
WHERE F1.dest_city NOT IN 
      (SELECT F2.dest_city
        FROM [dbo].[FLIGHTS] AS F2
        WHERE F2.origin_city = 'Seattle WA') AND
      F1.dest_city NOT IN 
      (SELECT F4.dest_city
        FROM [dbo].[FLIGHTS] AS F3 JOIN [dbo].[FLIGHTS] AS F4 
        ON F3.dest_city = F4.origin_city
        WHERE F3.origin_city = 'Seattle WA' AND
        F4.dest_city != 'Seattle WA')
ORDER BY city ASC;

/*
Output row : 4
Time : 46.734 second
Devils Lake ND
Hattiesburg/Laurel MS
Seattle WA
St. Augustine FL
*/