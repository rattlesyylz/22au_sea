WITH ShortTime AS
    (SELECT F1.origin_city, count(*) AS short
        FROM [dbo].[FLIGHTS] AS F1
        WHERE F1.canceled !=1 AND
        F1.actual_time < 180
        GROUP BY F1.origin_city),

    LongTime AS
    (SELECT F2.origin_city, count(*) AS long
        FROM [dbo].[FLIGHTS] AS F2
        WHERE F2.canceled !=1
        GROUP BY F2.origin_city)

SELECT L.origin_city, ISNULL(S.Short * 100.0 / L.Long, 0) AS percentage
FROM ShortTime AS S RIGHT OUTER JOIN LongTime AS L ON S.origin_city = L.origin_city
ORDER BY percentage ASC, origin_city ASC;

/*
Output row : 327
Time : 3.819 second
Guam TT	0.000000000000
Pago Pago TT	0.000000000000
Aguadilla PR	28.897338403041
Anchorage AK	31.812080536912
San Juan PR	33.660531697341
Charlotte Amalie VI	39.558823529411
Ponce PR	40.983606557377
Fairbanks AK	50.116550116550
Kahului HI	53.514471352628
Honolulu HI	54.739028823682
San Francisco CA	55.828864537188
Los Angeles CA	56.080890822987
Seattle WA	57.609387792231
Long Beach CA	62.176439513998
New York NY	62.371834136728
Kona HI	63.160792951541
Las Vegas NV	64.920256372037
Christiansted VI	65.100671140939
Newark NJ	65.849971096980
Plattsburgh NY	66.666666666666
*/