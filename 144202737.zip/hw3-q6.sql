SELECT DISTINCT C.name as carrier
FROM [dbo].[CARRIERS] AS C 
WHERE C.cid IN (SELECT F.carrier_id
                FROM [dbo].[FLIGHTS] AS F
                WHERE F.origin_city = 'Seattle WA' AND
                F.dest_city = 'San Francisco CA')
ORDER BY carrier ASC;

/*
Output row : 4
Time : 00.215 second
Alaska Airlines Inc.
SkyWest Airlines Inc.
United Air Lines Inc.
Virgin America
*/