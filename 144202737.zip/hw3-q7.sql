SELECT DISTINCT C.name as carrier
FROM [dbo].[FLIGHTS] AS F JOIN [dbo].[CARRIERS] AS C ON F.carrier_id = C.cid
WHERE F.origin_city = 'Seattle WA' AND
      F.dest_city = 'San Francisco CA'
ORDER BY carrier ASC;

/*
Output row : 4
Time : 00.156second
Alaska Airlines Inc.
SkyWest Airlines Inc.
United Air Lines Inc.
Virgin America
*/