.mode csv
.import months.csv MONTHS
.import weekdays.csv WEEKDAYS
.import carriers.csv CARRIERS
.import flights-small.csv FLIGHTS