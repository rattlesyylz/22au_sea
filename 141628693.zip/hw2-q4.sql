SELECT DISTINCT C.name
FROM FLIGHTS AS F JOIN CARRIERS AS C ON F.carrier_id = C.cid
GROUP BY F.day_of_month, C.name, F.month_id
HAVING COUNT(*) > 1000;

-- Output: 12 rows