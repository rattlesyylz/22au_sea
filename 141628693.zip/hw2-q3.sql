SELECT W.day_of_week, AVG(F.arrival_delay) AS delay
FROM FLIGHTS AS F JOIN WEEKDAYS AS W ON F.day_of_week_id = W.did
GROUP BY W.did
ORDER BY AVG(F.arrival_delay) DESC
LIMIT 1;

-- Output: 1 row