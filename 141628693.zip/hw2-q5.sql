SELECT C.name, AVG(F.canceled) * 100 AS percentage
FROM FLIGHTS AS F JOIN CARRIERS AS C on F.carrier_id = C.cid
WHERE F.origin_city = 'Seattle WA'
GROUP BY C.cid
HAVING AVG(F.canceled) > 0.005
ORDER BY AVG(F.canceled) * 100 ASC;

-- Answer: 6 rows