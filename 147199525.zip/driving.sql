CREATE TABLE InsuranceCo(
    name VARCHAR(100) PRIMARY KEY, 
    phone INT          
);

CREATE TABLE Person(
    ssn INT PRIMARY KEY, 
    name VARCHAR(100)
);

CREATE TABLE Vehicle(
    licensePlate VARCHAR(100) PRIMARY KEY, 
    year INT,
    maxLiability REAL,
    vssn INT REFERENCES Person(ssn),
    vname VARCHAR(100) REFERENCES InsuranceCo(name)  
);

CREATE TABLE Driver(
    dssn INT PRIMARY KEY REFERENCES Person(ssn),
    driverID INT, 
);

CREATE TABLE Car(
    clicensePlate VARCHAR(100) PRIMARY KEY REFERENCES Vehicle(licensePlate),
    make VARCHAR(100)
);

CREATE TABLE NonProfessionalDriver(
    nssn INT PRIMARY KEY REFERENCES Driver(dssn)
);

CREATE TABLE ProfessionalDriver(
    pssn INT PRIMARY KEY REFERENCES Driver(dssn),
    medicalHistory VARCHAR(100)
);

CREATE TABLE Truck(
    tlicensePlate VARCHAR(100) PRIMARY KEY REFERENCES Vehicle(licensePlate),
    capacity INT,
    tssn INT REFERENCES ProfessionalDriver(pssn)
);

CREATE TABLE Drives(
    dlicensePlate VARCHAR(100) REFERENCES Car(clicensePlate),
    rssn INT REFERENCES NonProfessionalDriver(nssn),
    PRIMARY KEY (dlicensePlate, rssn)
);

/*
b) The relation of "vname VARCHAR(100) REFERENCES InsuranceCo(name)" represents
"insures" in the E/R diagram. The reason of my representation is that the relationship
between Vehicle and Insurance is many to one, which means InsuranceCo could have many
Vehicle but each Vehicle could only have one insuranceCo. 

I chose the primary key "name" inside InsuranceCo as the reference. It means each Vehicle
we put in to table references a InsuranceCo, which could reduce the redundancy and 
avoid to create more tables.

c)
The representation of Operates is "tssn INT REFERENCES ProfessionalDriver(pssn)".
I use a table to represent Drives. 

For Operations, it is the relationship of many to one between Truck and ProfessionalDriver,
which means we could find a truck with knowing the ssn of professionalDriver 
(yet a professionalDriver could direct to many trucks.) 
For Drivers, the relationship between car and nonprofessionalDriver is many to many, 
which mean knowing the ssn of a nonprofessionalDriver is not enough to find the car.
Therefore, because of the above reason, we could use a REFERENCES to represent operates,
but we need a table to represent drivers.
*/