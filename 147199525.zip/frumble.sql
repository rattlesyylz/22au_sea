--1.
CREATE TABLE Sales(
    name VARCHAR(100), 
    discount VARCHAR(100),
    month VARCHAR(100),
    price  INT     
);


--2.
-- name -> price
SELECT COUNT(*)
FROM Sales AS S1, Sales AS S2
WHERE S1.name = S2.name AND S1.price != S2.price;

-- Does Not Exist: name -> discount
SELECT COUNT(*)
FROM Sales AS S1, Sales AS S2
WHERE S1.name = S2.name AND S1.discount != S2.discount;

-- month -> discount
SELECT COUNT(*)
FROM Sales AS S1, Sales AS S2
WHERE S1.month = S2.month AND S1.discount != S2.discount;

-- month price -> name, discount
SELECT COUNT(*)
FROM Sales AS S1, Sales AS S2
WHERE S1.month = S2.month AND S1.price = S2.price
AND S1.name != S2.name AND S1.discount != S2.discount;

-- name discount -> month, price
SELECT COUNT(*)
FROM Sales AS S1, Sales AS S2
WHERE S1.name = S2.name AND S1.discount = S2.discount
AND S1.month != S2.month AND S1.price != S2.price;

/*
I find the functional dependency is in the following.
name -> price
month -> discount
month price -> name, discount
name discount -> month, price
*/

/*
3.
We assume as Sales(N, D, M, P),
and we get name -> price and month -> discount from part 2.
 Notice {N} + = {N, P}
 1. We splite R to R1(N, P) and R2(N, D, M)
 2. R2 does not satisfy BCNF because {M} + = {M, D}
 3.  Split R2 to R21(M, D) and R22(M, N)
 4. R21 and R22 satisfy BCNF now
 Therefore, The result of decomposing R into BCNF is R1(N, P),
 R21(M, D), and R22(M, N).
 We could also write as R1(name, price),
 R21(month, discount), and R22(month, name).
*/

CREATE TABLE R1(
    name VARCHAR(100) PRIMARY KEY, 
    price INT     
);

CREATE TABLE R21(
    month VARCHAR(100) PRIMARY KEY,
    discount VARCHAR(100)
);

CREATE TABLE R22(
    month VARCHAR(100) REFERENCES R21(month),
    name VARCHAR(100) REFERENCES R1(name),
    PRIMARY KEY(month, name)
);

--4
INSERT INTO R1
SELECT DISTINCT name, price
FROM Sales;

INSERT INTO R21
SELECT DISTINCT month, discount
FROM Sales;

INSERT INTO R22
SELECT DISTINCT month, name
FROM Sales;

SELECT COUNT(*)
FROM R1;
-- 37 Rows

SELECT COUNT(*)
FROM R21;
-- 13 Rows

SELECT COUNT(*)
FROM R22;
-- 427 Rows